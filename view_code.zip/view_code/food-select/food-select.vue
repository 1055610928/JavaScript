<template>
    <view>
        <view class="icon_group" @click="closePopup">
            <text class="iconfont icon-Group-"></text>
        </view>
        <scroll-view scroll-y class="scroll">
            <view class="padding_card">
                <block v-for="(item, index) in singleCombos" :key="index">
                    <view class="category">
                        <text>{{item.comboTyeDesc}}</text>
                        <text v-if="item.chooseNumber>0">：请选择{{item.chooseNumber}}种</text>
                    </view>
                    <view class="container" :class="checkBoxConfig.column">
                        <view v-for="(item1, index1) in item.singleComboSkuDtos" :key="index1">
                            <view class="item"
                            :class="{'active':item1.isChecked,'disabled':item1.availableAmount==0}"
                            :data-son-index="index1"
                            :data-father-index="index"
                            @click="checkboxChange($event,item1,item.singleComboSkuDtos)">
                                <view>
                                    {{item1.comboName}}
                                </view>
                                <view>
                                    {{item1.price}}元
                                </view>
                         </view>
                        </view>
                    </view>
                </block>
            </view>
        </scroll-view>
        <view class="save shadow" @click="saveFood">确定</view>
    </view>
</template>

<script>
export default {
  data() {
    return{
        checkBoxConfig:{
            column:'col_3'
        },
        singleCombos:[],
        comboSkuIds:[],
        foods:[],
        foodsParams:{
            isSuccessAllFoods: false,
            comboSkuIds:[],
            foods:[],
            totalPrice:0
        },
        totalPrice:0,
        isChecked: false
    }
  },
  mounted(){
      this.getSingleCombos();
  },
  methods: {
    checkboxChange(e,item,items) {
        let sonIndex = Number(e.currentTarget.dataset.sonIndex);
        let fatherIndex = Number(e.currentTarget.dataset.fatherIndex);
        //选中或者取消选中的checkbox
        let singleComboSkuDtos = this.singleCombos[fatherIndex].singleComboSkuDtos[sonIndex];
        let selectedPrice=singleComboSkuDtos.price;
        if(singleComboSkuDtos.isChecked){
            this.foodsParams.totalPrice=this.foodsParams.totalPrice-selectedPrice;
            if(this.comboSkuIds[fatherIndex].includes(singleComboSkuDtos.comboSkuId)){
                this.removeComboSkuId(fatherIndex,singleComboSkuDtos.comboSkuId)
            }
            if(this.foodsParams.foods.includes(singleComboSkuDtos.comboName)){
                this.removeFood(singleComboSkuDtos.comboName)
            }
            this.$set(singleComboSkuDtos,"isChecked",false);
        }else{
            //1:存comboSkuIds，将选择的comboSkuIds存成二位数组
            //2:传递数据时，将数组comboSkuIds扁平化,扁平化操作在父组件操作
            if(singleComboSkuDtos.availableAmount == 0){
                this.vta.showToast(`${singleComboSkuDtos.comboName}已售完,看看其它的${this.singleCombos[fatherIndex].comboTyeDesc}吧`)
                return;
            }
            if(this.singleCombos[fatherIndex].chooseNumber > 0){
                if(this.comboSkuIds[fatherIndex].length == this.singleCombos[fatherIndex].chooseNumber){
                    this.vta.showToast(`${this.singleCombos[fatherIndex].comboTyeDesc}最多选择${this.singleCombos[fatherIndex].chooseNumber}种`)
                    return;
                }
            }
            this.foodsParams.totalPrice=this.foodsParams.totalPrice+selectedPrice;
            this.comboSkuIds[fatherIndex].push(singleComboSkuDtos.comboSkuId)
            //转换换成数组
            let [...transformSkuIdsArr] = new Set(this.comboSkuIds[fatherIndex]);
            this.comboSkuIds[fatherIndex] = transformSkuIdsArr
            //foods
            this.foodsParams.foods.push(singleComboSkuDtos.comboName)
            let [...foods] = new Set(this.foodsParams.foods)
            this.foodsParams.foods = foods;
            this.$set(singleComboSkuDtos,"isChecked",true);
        }
        console.log("price is ",this.foodsParams.totalPrice);
    },
    removeComboSkuId(i,val){
        console.log(this.comboSkuIds[i]);
        let index = this.comboSkuIds[i].indexOf(val);
        if (index > -1) {
            this.comboSkuIds[i].splice(index, 1);
        }
    },
    removeFood(val){
        let index = this.foodsParams.foods.indexOf(val);
        if(index > -1){
            this.foodsParams.foods.splice(index,1);
        }
    },
    getSingleCombos(){
        return new Promise(resolve=>{
            this.api("singleCombos",{
                data:{
                    skuId:this.skuId
                }
            }).then(res=>{
                if(res.length > 0){
                    this.singleCombos = res;
                    console.log(this.singleCombos);
                    res.forEach(item=>{
                        this.comboSkuIds.push([]);
                        this.foods.push({
                            comboTyeDesc:item.comboTyeDesc,
                            chooseNumber:item.chooseNumber
                        })
                    })
                    console.log(this.comboSkuIds);
                    resolve();
                }
            })
        })
    },
    sendParamsParentComponent(boolean){
        this.foodsParams.isSuccessAllFoods =  boolean;
        this.foodsParams.comboSkuIds = this.comboSkuIds;
    },
    saveFood(){
        for(let i=0; i<this.comboSkuIds.length; i++){
            if(this.comboSkuIds[i].length < this.foods[i].chooseNumber){
                this.vta.showToast(`请选择${this.foods[i].chooseNumber}种${this.foods[i].comboTyeDesc}`)
                this.sendParamsParentComponent(false)
                break;
            }else{
                this.foodsParams.isSuccessAllFoods = true
            }
        }
        console.log(this.foodsParams.isSuccessAllFoods);
        if(this.foodsParams.isSuccessAllFoods){
            this.foodsParams.comboSkuIds = this.comboSkuIds;
            this.$emit("getFoodsParams", this.foodsParams)
        }
    },
    closePopup(){
        for(let i=0; i<this.comboSkuIds.length; i++){
             if(this.comboSkuIds[i].length < this.foods[i].chooseNumber){
                 this.sendParamsParentComponent(false)
             }
        }
        this.$emit("closePopup",true,this.foodsParams.isSuccessAllFoods,this.foodsParams.foods,this.foodsParams.totalPrice);
    }
  },
  props:['skuId'],
  watch:{
      skuId(item){
            console.log(item);
            this.skuId = item;
            this.getSingleCombos();
            this.comboSkuIds = []
            this.foodsParams.foods = []
      }
  }
};
</script>

<style lang="scss" scoped>
    @import "./food-select.scss";
</style>