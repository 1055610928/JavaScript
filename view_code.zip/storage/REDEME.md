将utils挂在到main.js中

```js
Vue.prototype.storage = storage
```

使用方式：

- 添加数据
  - this.storage.test = '123'
- 更新数据
  - this.storage.test = '456'


- 获取数据
  - this.storage.test
- 删除数据
  - this.storage.delete('test')
- 删除所有数据
  - this.storage.deleteAll()